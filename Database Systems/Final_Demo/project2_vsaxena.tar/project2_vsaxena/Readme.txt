Step 1:

  Run the script in oracle
   
    >Start Proj2data

Step 2:

  Run the package in oracle

    >Start package

Step 3:

  Compile the java code in bingsuns

   >javac Driver.java

Step 4:

  Execute the java code

   >java Driver




Names:  Kundan Shrivastav  B00708841

        Sean Gallagher     B00448581

        Varun Saxena       B00715343


`
    
