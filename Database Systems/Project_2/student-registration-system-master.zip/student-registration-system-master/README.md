# student-registration-system
CS532 Design Patterns
Fall 2016
Project 2 README FILE

Due Date: Tuesday, November 29, 2016
Submission Date: Tuesday, November 29, 2016
Grace Period Used This Project: 0 Days
Grace Period Remaining: 0 Days
Creators: Saurabh Chaudhari, Triveni Banpela
e-mail: schaud14@binghamton.edu,tbanpel1@binghamton.edu


PURPOSE:
The purpose of this Project is to create student registration system using Oracle's PL/SQL and JDBC.

PERCENT COMPLETE:
To our knowlegde, the assignment is complete.

TO COMPLILE and run:
We need to import two jar files.
ojdbc6.jar
my-sql-connector.jar 

run hepler table script
run databaseprojet package in sql
run triggers
run sequence

import Driver.java in eclipse
and run

TESTING:
this code runs on Saurabh's machine.
Connection string is hardcoded.
Oracle version 12c.

PARTS THAT ARE NOT COMPLETE:
None.

BUGS:
None.

ACKNOWLEDGEMENT:
None.
