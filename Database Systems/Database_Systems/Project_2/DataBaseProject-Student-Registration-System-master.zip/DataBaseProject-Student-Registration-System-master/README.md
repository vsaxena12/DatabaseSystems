# DataBaseProject- Student Registration System

Student Registration system is a standalone system used to maintain student's enrollment and disenrollment of courses.The system has been developed using PL/SQL and Java JDBC connectivity. With the help of Triggers maintained logs of the operations performed by the users on the database. All the DML operations were performed only using PL/SQL.





